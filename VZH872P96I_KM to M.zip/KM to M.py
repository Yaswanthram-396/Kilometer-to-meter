a=float(input())
print(int(a*1000))